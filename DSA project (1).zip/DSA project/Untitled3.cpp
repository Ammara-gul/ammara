#include "tree.h"
#include <iostream>
using namespace std;

void tree::find(const std::string& key, node** par, node** loc) {
    node* ptr = root;
    *par = nullptr;

    while (ptr != nullptr) {
        if (key == ptr->word) {
            *loc = ptr;
            return;
        }
        *par = ptr;
        if (key < ptr->word) {
            ptr = ptr->lchild;
        } else {
            ptr = ptr->rchild;
        }
    }
    *loc = nullptr;
}

void tree::insert(const std::string& word, const std::string& meaning) {
    node *parent, *location;
    find(word, &parent, &location);

    if (location != nullptr) {
        cout << "Word already exists in the dictionary.\n";
        return;
    }

    node* tmp = new node{word, meaning, nullptr, nullptr};

    if (parent == nullptr) {
        root = tmp;
    } else if (word < parent->word) {
        parent->lchild = tmp;
    } else {
        parent->rchild = tmp;
    }
}

void tree::del(const std::string& word) {
    node *parent, *location;
    find(word, &parent, &location);

    if (location == nullptr) {
        cout << "Word not found in the dictionary.\n";
        return;
    }

    if (location->lchild == nullptr && location->rchild == nullptr) {
        case_a(parent, location);
    } else if (location->lchild != nullptr && location->rchild == nullptr) {
        case_b(parent, location);
    } else if (location->lchild == nullptr && location->rchild != nullptr) {
        case_b(parent, location);
    } else {
        case_c(parent, location);
    }

    delete location;
}

void tree::case_a(node* par, node* loc) {
    if (par == nullptr) {
        root = nullptr;
    } else if (loc == par->lchild) {
        par->lchild = nullptr;
    } else {
        par->rchild = nullptr;
    }
}

void tree::case_b(node* par, node* loc) {
    node* child = (loc->lchild != nullptr) ? loc->lchild : loc->rchild;

    if (par == nullptr) {
        root = child;
    } else if (loc == par->lchild) {
        par->lchild = child;
    } else {
        par->rchild = child;
    }
}

void tree::case_c(node* par, node* loc) {
    node* ptrsave = loc;
    node* ptr = loc->rchild;

    while (ptr->lchild != nullptr) {
        ptrsave = ptr;
        ptr = ptr->lchild;
    }

    loc->word = ptr->word;
    loc->meaning = ptr->meaning;

    if (ptr->lchild == nullptr && ptr->rchild == nullptr) {
        case_a(ptrsave, ptr);
    } else {
        case_b(ptrsave, ptr);
    }
}

void tree::inorder(node* ptr) {
    if (ptr != nullptr) {
        inorder(ptr->lchild);
        cout << ptr->word << ": " << ptr->meaning << endl;
        inorder(ptr->rchild);
    }
}

void tree::displayAll() {
    if (root == nullptr) {
        cout << "Dictionary is empty.\n";
    } else {
        inorder(root);
    }
}

void tree::searchWord(const std::string& word) {
    node *parent, *location;
    find(word, &parent, &location);

    if (location == nullptr) {
        cout << "Word not found in the dictionary.\n";
    } else {
        cout <<"Word = "<< word << "\nMeaning = " << location->meaning << endl;
    }
}

