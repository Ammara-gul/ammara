#ifndef TREE_H
#define TREE_H

#include <string>
using namespace std;

struct node {
    string word;
    string meaning;
    node* lchild;
    node* rchild;
};

class tree {
public:
    node* root = nullptr;

    void find(const std::string& key, node** par, node** loc);
    void insert(const std::string& word, const std::string& meaning);
    void del(const std::string& word);
    void case_a(node* par, node* loc);
    void case_b(node* par, node* loc);
    void case_c(node* par, node* loc);

    // Traversals
    void inorder(node* ptr);
    void displayAll();

    // Search
    void searchWord(const std::string& word);
};

#endif
