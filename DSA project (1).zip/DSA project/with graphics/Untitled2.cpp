#include "tree.h"
#include <graphics.h>
#include <iostream>
using namespace std;

void tree::find(int key, node** par, node** loc) {
    node* ptr = root;
    *par = nullptr;

    while (ptr != nullptr) {
        if (key == ptr->data) {
            *loc = ptr;
            return;
        }
        *par = ptr;
        if (key < ptr->data) {
            ptr = ptr->lchild;
        } else {
            ptr = ptr->rchild;
        }
    }
    *loc = nullptr;
}

void tree::insert(int data) {
    node *parent, *location;
    find(data, &parent, &location);

    if (location != nullptr) {
        cout << "Data already exists in the tree.\n";
        return;
    }

    node* tmp = new node{data, nullptr, nullptr};

    if (parent == nullptr) {
        root = tmp;
    } else if (data < parent->data) {
        parent->lchild = tmp;
    } else {
        parent->rchild = tmp;
    }
    drawTree(); // Update the tree visually after insertion
}

void tree::display(node* root, int x, int y, int level) {
    if (root == nullptr) return;

    // Draw the current node
    char buffer[10];
    sprintf(buffer, "%d", root->data);
    circle(x, y, 20);
    outtextxy(x - 10, y - 10, buffer);

    // Draw left child
    if (root->lchild != nullptr) {
        line(x, y, x - 50 / level, y + 50);
        display(root->lchild, x - 50 / level, y + 50, level + 1);
    }

    // Draw right child
    if (root->rchild != nullptr) {
        line(x, y, x + 50 / level, y + 50);
        display(root->rchild, x + 50 / level, y + 50, level + 1);
    }
}

void tree::drawTree() {
    cleardevice(); // Clear previous tree drawing
    display(root, getmaxx() / 2, 50, 2);
}
