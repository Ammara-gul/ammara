#include <graphics.h>
#include <iostream>
#include "tree.h"
using namespace std;

int main() {
    tree bst;
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "");

    int choice;
    while (true) {
        cout << "\nMenu:\n";
        cout << "1. Insert\n";
        cout << "2. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        if (choice == 1) {
            int value;
            cout << "Enter value to insert: ";
            cin >> value;
            bst.insert(value);
        } else if (choice == 2) {
            cout << "Exiting...\n";
            break;
        } else {
            cout << "Invalid choice. Try again.\n";
        }
    }

    closegraph();
    return 0;
}
