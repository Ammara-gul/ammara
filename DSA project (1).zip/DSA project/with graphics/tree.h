#ifndef TREE_H
#define TREE_H

#include <string>

struct node {
    int data;
    node* lchild;
    node* rchild;
};

class tree {
public:
    node* root = nullptr;

    void insert(int data);
    void find(int key, node** par, node** loc);
    void display(node* root, int x, int y, int level);
    void drawTree();
};

#endif
